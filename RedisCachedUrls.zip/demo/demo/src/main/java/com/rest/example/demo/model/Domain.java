package com.rest.example.demo.model;

import java.io.Serializable;
import javax.persistence.*;

public class Domain implements Serializable {
	@Column
	protected Boolean isActive = true;

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	
}
