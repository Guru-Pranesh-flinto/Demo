package com.rest.example.demo.model;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository
public class TinyURLDao extends BaseDao<FlintoTinyURL> {
	
	public Long getLargestBarcodeNumber () {
		try {
            Query query = getEntityManger().createQuery("select max(id) from FlintoTinyURL");
            Object object = query.getSingleResult();
            if (object != null) {
                return Long.valueOf(query.getSingleResult().toString());
            }
            return Long.valueOf(0);
        } catch (Exception e) {
            System.out.print("errorr    "+e);
        }
        return null;
	}
	
}
