package com.rest.example.demo.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class FliteringController {

}
