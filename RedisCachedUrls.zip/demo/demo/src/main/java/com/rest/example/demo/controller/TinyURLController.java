package com.rest.example.demo.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.rest.example.demo.exception.UrlNotFoundException;
import com.rest.example.demo.model.ITinyURLService;
import com.rest.example.demo.model.JSONResponse;
import com.rest.example.demo.model.TestCacheService;



@RestController
public class TinyURLController {
	
	@Autowired
	private ITinyURLService tinyURLService; 

	@Autowired
	private TestCacheService caching;
	
	
	@RequestMapping(value = "/create-tinyUrl/{longURL}",method = RequestMethod.GET)
	public JSONResponse generateTinyUrl(@PathVariable String longURL,HttpServletRequest request, HttpServletResponse response) {
		JSONResponse jsonResponse = new JSONResponse();
		String shortURL =caching.ReturnShortUrlfromCache(longURL); //tinyURLService.generateTinyURL(longURL);
		if(StringUtils.isEmpty(shortURL) || shortURL == null) {
			jsonResponse.setSuccess(Boolean.FALSE);
			jsonResponse.setMessage("Unable to generate ShortURL");
		}else {
			jsonResponse.setSuccess(Boolean.TRUE); 
			jsonResponse.setResult(shortURL);
			jsonResponse.setMessage("ShortURL generated successfully");
			
		}
		return jsonResponse;
	}
	
	@RequestMapping(value = "/{shortURL}",method = RequestMethod.GET)
	public JSONResponse covertToOriginal(@PathVariable String shortURL,HttpServletRequest request,
										HttpServletResponse response) throws Exception{
		String longURL = caching.ReturnLongUrlfromCache(shortURL);
		if(StringUtils.isEmpty(longURL) || longURL == null)
			throw new UrlNotFoundException("Given url not available");
		else
			response.sendRedirect("https://flintobox.com/"+longURL);

		return null;
	}
	
}
