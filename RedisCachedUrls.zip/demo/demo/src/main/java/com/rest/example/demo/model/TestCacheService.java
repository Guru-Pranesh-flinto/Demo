package com.rest.example.demo.model;



import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import ch.qos.logback.classic.Logger;

@Service
public class TestCacheService {
	
	@Autowired
	TinyURLService url;
	
	public static final String MY_KEY = "mykey";
	Logger _log = (Logger)LoggerFactory.getLogger(TestCacheService.class);	
	
	
	 @Cacheable(cacheNames = "myCache",key = "#root.target.MY_KEY")
	    public String cacheThis(){
		 	_log.error("Returning NOT from cache!");
	        return "CacheChanged";
	    }
	 
	 
	 // Cached Method calls to Generate tiny URLs and Fetch Long URLs. 
	@Cacheable(cacheNames="url",key="#s")
	 public String ReturnShortUrlfromCache(String s)
	 {
		return url.generateTinyURL(s);
	 }
	
	@Cacheable(cacheNames="longurl",key="#s")
	 public String ReturnLongUrlfromCache(String s) throws Exception
	 {
		return url.getLongURL(s);
	 }
	 
	
	 

}

