package com.rest.example.demo.model;

import java.io.Serializable;
import java.util.List;

public class JSONResponse<T extends Object> implements Serializable{
	
	private Boolean success;
    private ResponseCode responseCode;
    private String message;
    private T result;
    private List<T> results;
    
    
    
    
	public JSONResponse() {
		super();
	}
	public JSONResponse(Boolean success, ResponseCode responseCode, String message, T result, List<T> results) {
		super();
		this.success = success;
		this.responseCode = responseCode;
		this.message = message;
		this.result = result;
		this.results = results;
	}
	public Boolean getSuccess() {
		return success;
	}
	public void setSuccess(Boolean success) {
		this.success = success;
	}
	public ResponseCode getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(ResponseCode responseCode) {
		this.responseCode = responseCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public T getResult() {
		return result;
	}
	public void setResult(T result) {
		this.result = result;
	}
	public List<T> getResults() {
		return results;
	}
	public void setResults(List<T> results) {
		this.results = results;
	}
    
    

}
