package com.rest.example.demo.controller;
import com.rest.example.demo.model.*;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rest.example.demo.model.ITinyURLService;
import com.rest.example.demo.model.TinyURLService;

@RestController
public class HelloWorldController {
	
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private ITinyURLService tinyURLService;
	@Autowired
	private TestCacheService dummy;
	
	//Get
	//URL - /hello-world
	//method - hello-world
//	@RequestMapping(value = "/hello-world", method = RequestMethod.GET )
//	public String hello_world(){
//		String res = dummy.ReturnShortUrlfromCache("www.wiki.com");
//		return res;
//	}
	
	
	
	
	//Get
	//URL - /hello-world-international
	//method - hello_world_international
	//params- Accept-language as one of the param which needs to pass via requestHeader
	@RequestMapping(value = "/hello-world-international", method = RequestMethod.GET )
	public String hello_world_international(@RequestHeader(name="Accept-Language", required = false) Locale locale){
		return messageSource.getMessage("good.morning.message",null,locale);
	}

}
