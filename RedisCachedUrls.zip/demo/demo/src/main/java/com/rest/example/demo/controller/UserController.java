package com.rest.example.demo.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriComponents;

import com.rest.example.demo.user.User;
import com.rest.example.demo.user.UserDao;
import com.rest.example.demo.user.UserNotFoundException;



@RestController
public class UserController {

	@Autowired UserDao userDao;
	//Get
	//URI -- /users
	//method getAllUser
	@GetMapping(value = "/users")
	public List<User> getAllUser(){
		return userDao.findAll();
	}
	
	
	//Get
	//URL -- /find-user{userid}
	@RequestMapping(value = "/find-user/{userid}",method = RequestMethod.GET)
	public User retrieveUser(@PathVariable Integer userid)  throws Exception{
		//return userDao.findOne(userid);
		User user = userDao.findOne(userid);
		if(user == null) {
			throw new UserNotFoundException("id="+userid);
		}
		return user;
	}
	
		//Delete
		//URL -- /find-user{userid}
		@RequestMapping(value = "/deleteUser/{userid}",method = RequestMethod.DELETE)
		public void DeleteUserByID(@PathVariable Integer userid) {
			//return userDao.findOne(userid);
			User user = userDao.deleteUserByid(userid);
			if(user == null) {
				throw new UserNotFoundException("id="+userid);
			}
		
		}

	//post
	//uri -- /create-user
	// input {"name":"Sindhu","birthDate":"2020-05-03T20:30:58.175+0000"}
	// output {}
	@RequestMapping(value = "/create-user",method = RequestMethod.POST)
	public ResponseEntity<Object> createUser(@RequestBody User user) {
		System.out.println("value inserted"); 
		User savedUser = userDao.save(user); 
		
		 //URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(savedUser.getId()).toUri();
		URI location = ServletUriComponentsBuilder.fromUriString("/find-user/{userid}").
				buildAndExpand(savedUser.getId()).toUri();
		
		return ResponseEntity.created(location).build();
	}
	
}
